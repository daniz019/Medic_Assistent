import type { Disease } from "../types"

export const diseases: Disease[] = [
  {
    name: "Gripe",
    symptoms: ["febre", "dor de cabeça", "dor no corpo", "tosse", "fadiga"],
    description: "Infecção viral comum que afeta o sistema respiratório.",
  },
  {
    name: "Resfriado",
    symptoms: ["coriza", "espirros", "dor de garganta", "tosse leve", "congestão nasal"],
    description: "Infecção viral leve do trato respiratório superior.",
  },
  {
    name: "COVID-19",
    symptoms: ["febre", "tosse seca", "cansaço", "perda de paladar ou olfato", "dificuldade para respirar"],
    description: "Doença infecciosa causada pelo coronavírus SARS-CoV-2.",
  },
  {
    name: "Alergia",
    symptoms: ["espirros", "coceira nos olhos", "coriza", "congestão nasal", "tosse"],
    description: "Reação exagerada do sistema imunológico a substâncias geralmente inofensivas.",
  },
  {
    name: "Enxaqueca",
    symptoms: ["dor de cabeça intensa", "sensibilidade à luz", "náusea", "vômito", "visão turva"],
    description: "Tipo de dor de cabeça recorrente que pode causar dor intensa e outros sintomas.",
  },
]

