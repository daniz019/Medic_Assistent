import Link from "next/link"

export default function Footer() {
  return (
    <footer className="bg-gray-100 border-t border-gray-200">
      <div className="container mx-auto px-4 py-6">
        <div className="flex justify-between items-center">
          <p className="text-gray-600">&copy; 2023 Assistente Médico. Todos os direitos reservados.</p>
          <div className="space-x-4">
            <Link href="/privacidade" className="text-blue-600 hover:text-blue-800 transition-colors">
              Privacidade
            </Link>
            <Link href="/termos" className="text-blue-600 hover:text-blue-800 transition-colors">
              Termos de Uso
            </Link>
            <Link href="/contato" className="text-blue-600 hover:text-blue-800 transition-colors">
              Contato
            </Link>
          </div>
        </div>
      </div>
    </footer>
  )
}

