import Link from "next/link"

export default function Header() {
  return (
    <header className="bg-white shadow-sm">
      <nav className="container mx-auto px-4 py-4">
        <Link href="/" className="text-2xl font-bold text-blue-600 hover:text-blue-800 transition-colors">
          Assistente Médico
        </Link>
      </nav>
    </header>
  )
}

