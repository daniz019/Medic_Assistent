import { Disease, type ProcessedResult } from "../types"
import { diseases } from "../data/diseases"

export function processSymptoms(age: number, gender: "male" | "female", symptoms: string): ProcessedResult[] {
  const userSymptoms = symptoms
    .toLowerCase()
    .split(",")
    .map((s) => s.trim())

  const results: ProcessedResult[] = diseases.map((disease) => {
    const matchedSymptoms = disease.symptoms.filter((s) => userSymptoms.includes(s))
    const probability = (matchedSymptoms.length / disease.symptoms.length) * 100

    return {
      disease,
      probability,
    }
  })

  // Ajuste de probabilidade baseado em idade e gênero (simplificado)
  results.forEach((result) => {
    if (result.disease.name === "COVID-19" && age > 60) {
      result.probability *= 1.2 // Aumenta a probabilidade para idosos
    }
    if (result.disease.name === "Enxaqueca" && gender === "female") {
      result.probability *= 1.1 // Aumenta levemente a probabilidade para mulheres
    }
  })

  return results.sort((a, b) => b.probability - a.probability).slice(0, 3)
}

